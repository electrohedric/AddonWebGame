function setup() {
    createCanvas(200, 200);
}

function draw() {
    background(2);
    ellipse(mouseX, mouseY, 60, 60);
}